package trycatch;

public class MyClass 
{
    public static void main(String args[]) 
    {
        int[] array = new int[6];
        try 
        {
            array[9] = 6;
        }
        catch (ArrayIndexOutOfBoundsException e) 
        {
            System.out.println("index is out of bound :("); 
        }
        finally 
        {
            System.out.println("size of the array is " + array.length);
        }
    }
}
