package oops;
public class Cars 
{  
    String name; 
    String type; 
    int lifeofcar; 
    String color; 
    public Cars(String name, String type, int lifeofcar, String color) 
    { 
        this.name = name; 
        this.type = type; 
        this.lifeofcar = lifeofcar; 
        this.color = color; 
    } 
    public String getName() 
    { 
        return name; 
    } 
    public String gettype() 
    { 
        return type; 
    } 
    public int getlifeofcar() 
    { 
        return lifeofcar; 
    } 
    public String getColor() 
    { 
        return color; 
    } 
 
    public String toString() 
    { 
        return("Hi my car name is "+ this.getName()+ ".\nMy type,life of car and color are " + this.gettype()+", " + this.getlifeofcar()+ ", and"+" "+ this.getColor() + "."); 
    } 
    public static void main(String[] args) 
    { 
        Cars toyota = new Cars("toyota","fortuner", 25, "black"); 
        System.out.println(toyota.toString()); 
    } 
}

